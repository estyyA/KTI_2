using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyApp.Namespace
{
    public class AccountControllerModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
